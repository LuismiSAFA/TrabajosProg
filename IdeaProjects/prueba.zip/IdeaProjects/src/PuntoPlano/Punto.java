package PuntoPlano;

public interface Punto {
    Integer  getX();
    Integer getY();
    void setX(Integer x1);
    void setY(Integer y1);

}
